package com.gmail.nossr50.events.scoreboard;

public enum ScoreboardEventReason {
    CREATING_NEW_SCOREBOARD,
    OBJECTIVE,
    REVERTING_BOARD,
}
