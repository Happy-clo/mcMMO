package com.gmail.nossr50.events.scoreboard;

public enum ScoreboardObjectiveEventReason {
    UNREGISTER_THIS_OBJECTIVE,
    REGISTER_NEW_OBJECTIVE,
}
