//package com.gmail.nossr50.events.fake;
//
//import org.bukkit.entity.Player;
//import org.bukkit.event.player.PlayerAnimationEvent;
//import org.bukkit.event.player.PlayerAnimationType;
//
///**
// * Called when handling extra drops to avoid issues with NoCheat.
// */
//public class FakePlayerAnimationEvent extends PlayerAnimationEvent implements FakeEvent {
//    public FakePlayerAnimationEvent(Player player, PlayerAnimationType playerAnimationType) {
//        super(player, playerAnimationType);
//    }
//}
