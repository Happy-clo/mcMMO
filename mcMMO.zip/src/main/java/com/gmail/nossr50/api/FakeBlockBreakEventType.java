package com.gmail.nossr50.api;

public enum FakeBlockBreakEventType {
    FAKE,
    TREE_FELLER
}
