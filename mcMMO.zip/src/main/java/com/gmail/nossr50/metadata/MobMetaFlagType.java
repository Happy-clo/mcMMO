package com.gmail.nossr50.metadata;

public enum MobMetaFlagType {
    MOB_SPAWNER_MOB,
    EGG_MOB,
    NETHER_PORTAL_MOB,
    COTW_SUMMONED_MOB,
    PLAYER_BRED_MOB,
    PLAYER_TAMED_MOB,
    EXPLOITED_ENDERMEN,
}
