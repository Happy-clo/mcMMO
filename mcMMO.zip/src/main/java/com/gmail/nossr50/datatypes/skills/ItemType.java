package com.gmail.nossr50.datatypes.skills;

public enum ItemType {
    ARMOR,
    TOOL,
    OTHER
}
