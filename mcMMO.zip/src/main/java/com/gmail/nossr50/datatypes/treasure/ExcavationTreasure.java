package com.gmail.nossr50.datatypes.treasure;

import org.bukkit.inventory.ItemStack;

public class ExcavationTreasure extends Treasure {
    public ExcavationTreasure(ItemStack drop, int xp, double dropChance, int dropLevel) {
        super(drop, xp, dropChance, dropLevel);
    }
}
