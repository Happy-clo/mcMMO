package com.gmail.nossr50.datatypes.notifications;

public enum SensitiveCommandType {
    XPRATE_MODIFY,
    XPRATE_END,
    MMOEDIT
}
