package com.gmail.nossr50.datatypes.player;

public enum UniqueDataType {
    CHIMAERA_WING_DATS
}
