package com.gmail.nossr50.datatypes;

public enum MobHealthbarType {
    HEARTS,
    BAR,
    DISABLED
}