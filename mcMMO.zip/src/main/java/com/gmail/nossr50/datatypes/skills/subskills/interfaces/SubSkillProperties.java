package com.gmail.nossr50.datatypes.skills.subskills.interfaces;

public interface SubSkillProperties {
    boolean isSuperAbility();

    boolean isActiveUse();

    boolean isPassive();
}
