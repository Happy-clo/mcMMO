package com.gmail.nossr50.datatypes.treasure;

import org.bukkit.inventory.ItemStack;

public class FishingTreasure extends Treasure {

    public FishingTreasure(ItemStack drop, int xp) {
        super(drop, xp, 0, 0);
    }
}
