package com.gmail.nossr50.database;

import org.jetbrains.annotations.NotNull;

public interface UserQueryName extends UserQuery {
    @NotNull String getName();
}
