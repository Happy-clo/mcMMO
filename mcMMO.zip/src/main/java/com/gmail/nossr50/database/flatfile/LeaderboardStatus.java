package com.gmail.nossr50.database.flatfile;

public enum LeaderboardStatus {
    TOO_SOON_TO_UPDATE,
    UPDATED,
    FAILED
}
