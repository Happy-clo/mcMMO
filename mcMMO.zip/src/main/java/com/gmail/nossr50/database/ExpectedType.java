package com.gmail.nossr50.database;

public enum ExpectedType {
    STRING,
    INTEGER,
    LONG,
    BOOLEAN,
    FLOAT,
    DOUBLE,
    UUID,
    IGNORED,
    OUT_OF_RANGE
}
