package com.gmail.nossr50.database;

public enum UserQueryType {
    UUID_AND_NAME,
    UUID,
    NAME
}
