package com.gmail.nossr50.util.compat;

public enum CompatibilityType {
    PERSISTENT_DATA,
    BUNGEE_SERIALIZER,
    MASTER_ANGLER,
}
