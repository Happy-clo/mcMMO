package com.gmail.nossr50.util.compat.layers.skills;

import com.gmail.nossr50.util.compat.layers.AbstractCompatibilityLayer;

public abstract class AbstractMasterAnglerCompatibility extends AbstractCompatibilityLayer {
}
