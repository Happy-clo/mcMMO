//package com.gmail.nossr50.skills.woodcutting;
//
//import com.gmail.nossr50.config.Config;
//import com.gmail.nossr50.config.experience.ExperienceConfig;
//import com.gmail.nossr50.datatypes.skills.PrimarySkillType;
//import com.gmail.nossr50.mcMMO;
//import com.gmail.nossr50.util.BlockUtils;
//import com.gmail.nossr50.util.Misc;
//import com.gmail.nossr50.util.skills.SkillUtils;
//import org.bukkit.Material;
//import org.bukkit.block.BlockFace;
//import org.bukkit.block.BlockState;
//import org.bukkit.inventory.ItemStack;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Set;
//
//public final class Woodcutting {
//    public static int treeFellerThreshold = Config.getInstance().getTreeFellerThreshold();
//
//    private Woodcutting() {}
//
//
//
//
//}
