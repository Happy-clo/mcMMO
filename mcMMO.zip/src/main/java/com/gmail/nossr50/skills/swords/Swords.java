package com.gmail.nossr50.skills.swords;

import com.gmail.nossr50.mcMMO;

public class Swords {
    public static double  counterAttackModifier      = mcMMO.p.getAdvancedConfig().getCounterModifier();

    public static double serratedStrikesModifier   = mcMMO.p.getAdvancedConfig().getSerratedStrikesModifier();
}
