package com.gmail.nossr50.skills.repair;

import com.gmail.nossr50.mcMMO;

public class ArcaneForging {

    public static boolean arcaneForgingDowngrades  = mcMMO.p.getAdvancedConfig().getArcaneForgingDowngradeEnabled();
    public static boolean arcaneForgingEnchantLoss = mcMMO.p.getAdvancedConfig().getArcaneForgingEnchantLossEnabled();
}
